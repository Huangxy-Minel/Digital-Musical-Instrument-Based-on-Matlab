[do,~] = audioread('D:\MATLAB\R2016a\Sound Console#1\piano\piano re.wav');
sound(do,44100)